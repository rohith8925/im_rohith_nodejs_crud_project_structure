import xlsx from 'xlsx'
import fs from 'fs'
let rawFile = fs.readFileSync("./data.json")
let raw = JSON.parse(rawFile)
let files  = []
for (each in raw){
    files.push(raw[each])
    }  
let obj = files.map((e) =>
{
    return e
})

   let newWB = xlsx.book_new()

   let newWS = xlsx.utils.json_to_sheet(obj)

   xlsx.utils.book_append_sheet(newWB,newWS,"name")//workbook name as param

   xlsx.writeFile(newWB,"Sample-Sales-Data.xlsx")//file name as param
import { excelData } from "../dao/excel_Dao.js";
export const excelService = async () => {
  const arr = await excelData();

  arr.forEach((data) => {
    data.available_qty = data.Quantity - data["Returned Qty"];
  

})
return arr
}
  

import { excelService } from "../Service/excelService.js";
export const excelController = async (req, res) => {
const result = await excelService();
console.log('------',result);
res.json(result);
};

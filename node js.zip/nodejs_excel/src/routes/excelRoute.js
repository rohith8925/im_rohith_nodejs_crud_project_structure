import { Router } from "express";
import { excelController } from "../controller/excelController.js";
export const excelRoute = Router();
excelRoute.get("/getexcel", excelController);

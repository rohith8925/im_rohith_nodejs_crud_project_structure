import excel from "xlsx";
export const excelData = async () => {
const excelWorkbook = excel.readFile(
    "C:\\XX1489_Rohith D_PD-Full Stack Development\\Full Stack Development\\nodejs_excel\\src\\excel\\material_receiving_data.xlsx"
);
const excelName = excelWorkbook.SheetNames[0]; // read 1st sheet
//convert workbook to array of object
let res = await excel.utils.sheet_to_json(excelWorkbook.Sheets[excelName]);
return res;
};

import express from "express";
import { excelRoute } from "./src/routes/excelRoute.js";
const app = express();
app.use(express.json());
app.use("/excel", excelRoute);

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`server listening on port ${PORT}`));

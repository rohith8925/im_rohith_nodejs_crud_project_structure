import oracledb from "oracledb";

//establish connection 

let connection;
async function dbConn() {
    try {
        console.log('----calling-----')
        connection = await oracledb.getConnection({
            user: "xxtct12",
            password: "xxtct12",
            connectString: "172.16.2.91:1521/UAT"
        });
        console.log('connection', connection)
        console.log("Oracle DB successfully connected..!!")

    } catch (error) {

        console.log('catch', error)

    } 
}

dbConn();

//read script
async function read (req, res) {
    console.log('---------request-------',req.body)
    // let opts = {autoCommit:true};
    try{
    const result = await connection.execute(`select * from xx1489_persons`)
    console.log('result',result)
    console.log("Record reads successfully..!!");
}
catch(error)
{
    console.log(error);
}
}

export{read}
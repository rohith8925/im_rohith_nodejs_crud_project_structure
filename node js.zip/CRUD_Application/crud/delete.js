import oracledb from "oracledb";

//establish connection 

let connection;
async function dbConn() {
    try {
        console.log('----calling-----')
        connection = await oracledb.getConnection({
            user: "xxtct12",
            password: "xxtct12",
            connectString: "172.16.2.91:1521/UAT"
        });
        console.log('connection', connection)
        console.log("Oracle DB successfully connected..!!")

    } catch (error) {

        console.log('catch', error)

    } 
}

dbConn();

//delete script
async function del (req, res) {
    console.log('---------request-------',req.body)
    let opts = {autoCommit:true};
    try{
    const result = await connection.execute("delete from xx1489_persons where person_id = :person_id" ,{
        person_id :{val:req.body.person_id}
        // last_name :{val:req.body.last_name}
        // last_name :{val:req.body.last_name}
    },opts)
    console.log('result',result)
    return res.send({
    message : "successfully deleted",
    rowsAffected:result.rowsAffected
  })
}
catch(error)
{
    console.log(error);
}
}

export{del}
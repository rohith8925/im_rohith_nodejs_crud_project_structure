//Import required files
import Route from 'express';
import bodyParser from "body-parser";
import { insert } from "./crud/insert.js";
import { read } from './crud/read.js';
import { update } from './crud/update.js';
import { del } from './crud/delete.js';

//store route and port
const route = Route()
const Port = 8095;

//convert post data to request body
route.use(bodyParser.json());

//route the API
route.post('/api/person/insert',insert)
route.get('/api/person/read',read)
route.put('/api/person/update',update)
route.delete('/api/person/delete',del)


//establish the port
route.listen(Port,()=>{
    console.log('Server is start running: '+Port)
})
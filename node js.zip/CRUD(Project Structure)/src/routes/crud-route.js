import { Router } from 'express'
// import { connection } from '../config/_db.js'
import { insertpersonController, personController, updatepersonController,deletepersonController,flpersoncontroller} from '../controller/personController.js'
import { verifyjwt } from '../middleware/authorization.js'
export const crudRoute = Router()

// // create
// crudRoute.post('/', async (req, res) => {
//   try {
//     const newData = await connection.execute('insert into node_crud_em (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11)', Object.values({ ...req.body, HIRE_DATE: new Date(req.body.HIRE_DATE) }), { autoCommit: true })
//     res.json(newData)
//   } catch (error) {
//     res.send(error)
//   }
// })

// read
// crudRoute.get('/getAllEmployees', async (req, res) => {
//   try {
//     const allEmployees = await connection.execute('select * from node_crud_employee')
//     res.json(allEmployees.rows)
//   } catch (error) {
//     res.json(error)
//   }
// })

crudRoute.get('/getAllpersons', verifyjwt,personController)
crudRoute.post('/insertPerson',insertpersonController)
crudRoute.put('/updatePerson',updatepersonController)
crudRoute.delete('/deletePerson',deletepersonController)
crudRoute.get('/login',flpersoncontroller)

// crudRoute.get('/emp', async (req, res) => {
//   try {
//     const employee = await connection.execute('select * from node_crud_employee where employee_id = :id', [req.query.id])
//     res.json(employee.rows)
//   } catch (error) {
//     res.json(error)
//   }
// })

// // update
// crudRoute.put('/', async (req, res) => {
//   try {
//     const update = await connection.execute('update node_crud_employee set first_name = :1 where employee_id = :2', [req.query.name, req.query.id], { autoCommit: true })
//     res.json(update)
//   } catch (error) {
//     res.json(error)
//   }
// })

// // delete
// crudRoute.delete('/', async (req, res) => {
//   try {
//     const deletedData = await connection.execute('delete from node_crud_employee where employee_id = :id', [req.query.id])
//     res.json(deletedData)
//   } catch (error) {
//     res.json(error)
//   }
// })

import { connection } from '../config/_db.js'

//read
export const personDao = async () => {
  const result = await connection.execute('select * from xx1489_persons')
  return result.rows
}

//insert
export async function insertPersonDao(obj) {
  console.log('---------request-------', obj)
  let opts = { autoCommit: true };

  try {
    const result = await connection.execute("insert into xx1489_persons values " +
      "(:person_id,:first_name,:last_name)", {
      person_id: { val:obj.person_id },
      first_name: { val:obj.first_name },
      last_name: { val:obj.last_name }
    }, opts)
    console.log('result', result)
    return  {
      message: "successfully inserted",
      rowsAffected: result.rowsAffected
    }
  }
  catch (error) {
    console.log(error);
  }
}

// first_name and last_name

export async function flNameDao(obj)
{
  console.log('----------dddd--',obj)
  // let opts = {autoCommit:true};
  try{
    const result = await connection.execute("select * from xx1489_persons where first_name = :first_name and last_name = :last_name",{
      first_name :{val:obj.first_name},
      last_name : {val:obj.last_name}
    })
    console.log('Result',result)
    return{
      message : "successfully login",
      data : result.rows
    }
  }
  catch(error)
   {
     console.log(error);
   }
}

//update
export async function updatePersonDao (obj) {
  console.log('---------request-------',obj)
  let opts = {autoCommit:true};
  try{
  const result = await connection.execute("update xx1489_persons set last_name = :last_name where person_id = :person_id" ,{
      person_id :{val:obj.person_id},
      last_name :{val:obj.last_name}
      // last_name :{val:req.body.last_name}
  },opts)
  console.log('result',result)
  return {
  message : "successfully updated",
  rowsAffected:result.rowsAffected
}
}
catch(error)
{
  console.log(error);
}
}

//delete

export async function deletePersonDao (obj) {
  console.log('---------request-------',obj)
  let opts = {autoCommit:true};
  try{
  const result = await connection.execute("delete from xx1489_persons where person_id = :person_id" ,{
      person_id :{val:obj.person_id}
      // last_name :{val:req.body.last_name}
      // last_name :{val:req.body.last_name}
  },opts)
  console.log('result',result)
  return {
  message : "successfully deleted",
  rowsAffected:result.rowsAffected
}
}
catch(error)
{
  console.log(error);
}
}

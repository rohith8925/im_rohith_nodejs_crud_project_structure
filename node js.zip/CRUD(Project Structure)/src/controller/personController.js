import { personService,insertPersonService,updatePersonService,deletePersonService,flPersonService} from '../service/personService.js'

//read
export const personController = async (req, res) => {
  
  const result = await personService()
  res.json(result) 
}

// insert
export const insertpersonController = async (req, res) => {
  const result = await insertPersonService(req.body)
  if(!req.body.first_name)
  {
    res.json({Messgae :"firstName fields is required"})
  }
  else
  {
  res.json(result)
  }
  }

//update
export const updatepersonController = async (req, res) => {
  const result = await updatePersonService(req.body)
  if(!req.body.last_name)
  {
    res.json({ Message : "Last Name is required to update person"})
  }
  else{
  res.json(result)
  }
}

//delete
export const deletepersonController = async (req, res) => {
  const result = await deletePersonService(req.body)
  // console.log("--------------",req.body)
    res.json(result)
}


//first_name and last_name


export const flpersoncontroller = async(req,res) =>
{
  const result = await flPersonService(req.body)
  res.json(result)
}



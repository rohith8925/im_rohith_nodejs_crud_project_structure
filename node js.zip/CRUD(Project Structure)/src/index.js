import express from 'express'
import 'dotenv/config'

// routers
import { crudRoute } from './routes/crud-route.js'


const app = express()
app.use(express.json())

app.use('/crud', crudRoute)

// app.get('/', (obj) => {
//   obj.send('index')
// })

const PORT = process.env.PORT || 8080
app.listen(PORT, () => console.log(`server listening on http://localhost:${PORT}`))

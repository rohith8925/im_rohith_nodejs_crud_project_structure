import oracledb from 'oracledb'

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT

export let connection
try {
  connection = await oracledb.getConnection({
    user: process.env.USER_NAME,
    password: process.env.PASSWORD,
    connectString: process.env.CONNECTION_STRING,
  })
  console.log('oracledb connected successfully')
} catch (err) {
  console.error(err)
}

import { personDao,insertPersonDao,updatePersonDao,deletePersonDao,flNameDao } from '../dao/personDao.js'
import jsonWebToken from 'jsonwebtoken'

//read
export const personService = async () => {
  const result = await personDao()
  return result
}

//insert
export const insertPersonService = async (obj) =>
{
  const result = await insertPersonDao(obj)
  return result
}

//update
export const updatePersonService = async (obj) =>
{
  const result = await updatePersonDao(obj)
  return result
}
//delete
export const deletePersonService = async (obj) =>
{
  const result = await deletePersonDao(obj)
  return result
}

//first_name and last_name

export const flPersonService = async(obj) =>
{
  const result = await flNameDao(obj)
  const token = jsonWebToken.sign(
    {first_name:obj.first_name,last_name:obj.last_name},
    process.env.TOKEN_KEY,
    {
      expiresIn:"2h",
    }
  );
  result.token = token
  return result
}



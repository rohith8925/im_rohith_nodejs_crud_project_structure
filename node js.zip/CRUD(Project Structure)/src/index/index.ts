//multiple files compiled at once

console.log('------hello world--------');

var name1:string = "John"; 
var score1:number = 50;
var score2:number = 42.50
var sum = score1 + score2 
console.log("name"+name1) 
console.log("first score: "+score1) 
console.log("second score: "+score2) 
console.log("sum of the scores: "+sum)

// string
let firstName: string = "Rohith"; // type string

console.log(typeof firstName);

//reassign

let lastName: string = "D"; // type string

lastName = 33; // try to re-assign the value to a different type

console.log(lastName);

//array

const names: string[] = [];

names.push("D"); // no error

names.push(3); // Error: Argument of type 'number' is not assignable to parameter of type 'string'.

console.log(names);

//object

const car: { type: string, model: string, year: number } = {
    type: "Toyota",
    model: "Corolla",
    year: 2009
  };
  
  console.log(car);

  //template literal

  let val1 = "hello"
  let val2 = "hi"

  console.log(`${val1} and ${val2}`)


  let convert1 = (value:String) =>
  {
    return value.toUpperCase()
  }
  console.log(convert1('rohith'))


let message:string = "Hello World" 
console.log(message)

//number

let num:number = 'rohith' //assign string to number
console.log(num)

//any

const student: any = {name: "Harry Potter", age: 12}

console.log(student)

// change string

const student: string = {name: "Harry Potter", age: 12}

console.log(student)





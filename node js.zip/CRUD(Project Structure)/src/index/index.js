//multiple files compiled at once
console.log('------hello world--------');
var name1 = "John";
var score1 = 50;
var score2 = 42.50;
var sum = score1 + score2;
console.log("name" + name1);
console.log("first score: " + score1);
console.log("second score: " + score2);
console.log("sum of the scores: " + sum);
// string
var firstName = "Rohith"; // type string
console.log(typeof firstName);
//reassign
var lastName = "D"; // type string
lastName = 33; // try to re-assign the value to a different type
console.log(lastName);
//array
var names = [];
names.push("D"); // no error
names.push(3); // Error: Argument of type 'number' is not assignable to parameter of type 'string'.
console.log(names);
//object
var car = {
    type: "Toyota",
    model: "Corolla",
    year: 2009
};
console.log(car);
//template literal
var val1 = "hello";
var val2 = "hi";
console.log("".concat(val1, " and ").concat(val2));
var convert1 = function (value) {
    return value.toUpperCase();
};
console.log(convert1('rohith'));
var message = "Hello World";
console.log(message);
//number
var num = 'rohith'; //assign string to number
console.log(num);
//any
var student = { name: "Harry Potter", age: 12 };
console.log(student);
// change string
var student = { name: "Harry Potter", age: 12 };
console.log(student);
